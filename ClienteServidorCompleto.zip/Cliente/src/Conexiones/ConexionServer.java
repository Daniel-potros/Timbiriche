    
package Conexiones;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author labcisco
 */
public class ConexionServer {
    private Socket socket;
    private DataInputStream inputStream;
    private DataOutputStream outputStream;
    
    public ConexionServer(){
        try {
            this.socket= new Socket("localhost", 2323);
            this.inputStream = new DataInputStream(this.socket.getInputStream());
            this.outputStream = new DataOutputStream(this.socket.getOutputStream());
            } catch (IOException ex) {
            ex.printStackTrace();    
        }
    }
    
    public String recibirMensaje(){
        
        String fromServer = "";
        try {
            this.outputStream.writeUTF(Options.MESSAGE.toString());
            fromServer = this.inputStream.readUTF();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return fromServer;
    }
    
    public void cerrarConexion(){
        try {
            this.outputStream.writeUTF(Options.CLOSE.toString());
            
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
}
