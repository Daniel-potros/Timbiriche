/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runner;

import Conexiones.ConexionServer;
import java.util.Scanner;

/**
 *
 * @author labcisco
 */
public class Run {
    
    public static void main(String[] args) {
        ConexionServer c = new ConexionServer();
        Scanner sc = new Scanner(System.in);
        String aux="";
        while (! aux.equalsIgnoreCase("Close")) {
            System.out.println("Escriba su opción");
            aux = sc.nextLine();
            if (aux.equalsIgnoreCase("Message")) {
                System.out.println("Mensaje del servidor "+ c.recibirMensaje());
                
            }
            
        }
        sc.close();
        c.cerrarConexion();
    }
    
}
