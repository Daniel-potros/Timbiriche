/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Connections;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author labcisco
 */
public class ClientWorker implements Runnable{
    
    private Socket socket;
    private DataInputStream inputStream;
    private DataOutputStream outputStream;
    
    public ClientWorker(Socket socket) throws IOException{
        this.socket = socket;
        this.inputStream = new DataInputStream(this.socket.getInputStream());
        this.outputStream = new DataOutputStream(this.socket.getOutputStream());
    }

    @Override
    public void run() {
        boolean isConnected = true;
        while (isConnected) {            
            try {
                isConnected = this.chooseOptions(isConnected);
            } catch (IOException ex) {
               ex.printStackTrace();
            }
        }
    }
    
    private boolean chooseOptions(boolean isConnected) throws IOException{
        Options aux = Options.valueOf(this.inputStream.readUTF());
        switch(aux){
        case MESSAGE:
            this.message();
            break;
        case CLOSE:
            isConnected = false;
            break;
        default:
            break;
        }
        return isConnected;
    }
    
    private void message() throws IOException{
        this.outputStream.writeUTF("Se ha conectado al servidor");
    }
    
    @Override
    protected void finalize()throws Throwable{
        
    }
    
}
