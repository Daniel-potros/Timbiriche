/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Connections;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author labcisco
 */
public class Server {
    private ServerSocket serverSocket;
    
    public Server(){
        try {
            this.serverSocket = new ServerSocket(2323);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public void startToListen()throws IOException{
        while (true) {            
            Socket cliente = this.serverSocket.accept();
            new Thread(new ClientWorker(cliente)).start();
            //System.out.println("Se acepta un cliente");
        }
    }
    
}
