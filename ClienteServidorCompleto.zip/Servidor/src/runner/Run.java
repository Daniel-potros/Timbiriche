/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runner;

import Connections.Server;
import java.io.IOException;


/**
 *
 * @author labcisco
 */
public class Run {
    public static void main(String[] args) {
        try {
            new Server().startToListen();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
